// Zana brand map theme: warm cream land, teal water/highlights, clean and
// uncluttered (transit/business POI labels hidden — they add noise on a
// ride-booking map and don't match the flat, branded look).
export const ZANA_MAP_STYLE: google.maps.MapTypeStyle[] = [
  { elementType: 'geometry', stylers: [{ color: '#F7F5EF' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#5B6660' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#F7F5EF' }] },

  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#BFE6DC' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#00806A' }] },

  { featureType: 'landscape', elementType: 'geometry', stylers: [{ color: '#F7F5EF' }] },
  { featureType: 'landscape.natural', elementType: 'geometry', stylers: [{ color: '#E9F2ED' }] },

  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#DCEEE4', visibility: 'on' }] },

  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#FFFFFF' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#E5E3DA' }] },
  { featureType: 'road.arterial', elementType: 'geometry', stylers: [{ color: '#FFFFFF' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#FFC244' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#E6A82E' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#7A5A0E' }] },
  { featureType: 'road.local', elementType: 'labels', stylers: [{ visibility: 'off' }] },

  { featureType: 'transit', stylers: [{ visibility: 'off' }] },

  { featureType: 'administrative', elementType: 'labels.text.fill', stylers: [{ color: '#00806A' }] },
  { featureType: 'administrative.land_parcel', stylers: [{ visibility: 'off' }] },
];
